function F = sdisplay(X)
% DISPLAY Overloaded

try
    error('Not implemented. Convert to SDPVAR first')
catch
    disp('Incomplete block variable.');
end
